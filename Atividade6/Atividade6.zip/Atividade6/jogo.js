alert("Jogando pedra papel e tesoura!");

escolha = prompt("Qual você escolhe? Pedra, papel ou tesoura?");

var computerChoice = Math.random();

if (computerChoice < 0.34) {

computerChoice = "pedra";

} else if(computerChoice <= 0.67) {

computerChoice = "papel";

} else {

computerChoice = "tesoura";

} alert("Computador: " + computerChoice);

if (computerChoice === "pedra" &  escolha === "tesoura"){
	alert("Computador venceu, pois pedra quebra tesoura.");
}

if (escolha === "pedra" &  computerChoice === "tesoura"){
	alert("Você venceu! Pedra quebra tesoura.");
}

if (computerChoice === "tesoura" &  escolha === "papel"){
	alert("Computador venceu, pois tesoura corta papel");
}

if (computerChoice === "papel" &  escolha === "tesoura"){
	alert("Você venceu! Tesoura corta papel");
}

if (computerChoice === "papel" &  escolha === "pedra"){
	alert("Computador venceu, pois papel cobre pedra");
}
if (computerChoice === "pedra" &  escolha === "papel"){
	alert("Você venceu! Papel cobre pedra");
}

if (escolha === "tesoura" & computerChoice === "tesoura") {
	alert("Empatou!");
}

if (escolha === "pedra" & computerChoice === "pedra") {
	alert("Empatou!");
}
if (escolha === "papel" & computerChoice === "papel") {
	alert("Empatou!");
}