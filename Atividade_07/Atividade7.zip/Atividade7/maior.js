num1 = prompt("Informe o primeiro número: ");
num2 = prompt("Informe o segundo número: ");
num3 = prompt("Informe o terceiro número: ");

function maior(num1, num2, num3) {

	if (num1 == num2 && num1 == num3) {
		return ("Os números iguais.");
	}
	else {
		if (num1 > num2 && num1 > num3) {
			return ("O primeiro número: " + num1 + " é o maior.");
		}
		else {
			if (num2 > num1 && num2 > num3) {
				return ("O segundo número: " + num2 + " é o maior.");
			}
			else {
				if (num3 > num1 && num3 > num2) {
					return ("O terceiro número: " + num3 + " é o maior.");
				}
			}
		}
	}
}
	alert(maior(num1, num2, num3));