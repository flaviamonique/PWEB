var Aluno = {
  ra: '0030481921001',
  nome: 'Flavia'
}
alert("RA: " + Aluno.ra + "\nNome: " + Aluno.nome);

Aluno['ra'] = '0030481921002';
Aluno['nome'] = 'Luiza';
alert("RA: " + Aluno.ra + "\nNome: " + Aluno.nome);

Aluno.ra = '0030481921003';
Aluno.nome = 'Amanda';
alert("RA: " + Aluno.ra + "\nNome: " + Aluno.nome);

